export const data = {
    experience: [
      {
        title: "Junior Developer",
        subTitle: "Restory Healthy Tech Pvt Ltd",
        description:
          " Front End Developer ",
      },{
        title: "Software Developer",
        subTitle: "Restory Healthy Tech Pvt Ltd",
        description:
          " Front End Developer ",
      }
    ],
    education: [
      {
        title: "health domain",
        subTitle: "using react and php",
        description:
          "Developed and maintained a medical records management system using React.js, and Redux, resulting in increased efficiency and accuracy in patient data management",
      },
      {
        title: "Ecommerce project",
        subTitle: "using react and redux",
        description:
          "12th Grade in Science",
      },
      {
        title: "CRM",
        subTitle: "using react and php and bootstrap",
        description:
          "Bachelor of technology in computer science",
      },
    ],
    academicprojet:[
        {
            title: "TODO",
            subTitle: "using react and php and bootstrap",
            description:
              "Bachelor of technology in computer science",
          },
          {
            title: "CRUD",
            subTitle: "using react and redux and bootstrap",
            description:
              "create read update delete ",
          },
          {
            title: "Calculator",
            subTitle: "using react ",
            description:
              "Bachelor of technology in computer science",
          },
          {
            title: "Calender",
            subTitle: "using react ",
            description:
              "Bachelor of technology in computer science",
          },
          {
            title: "Form Validation",
            subTitle: "using react and php and bootstrap",
            description:
              "Bachelor of technology in computer science",
          },
    ]
  };